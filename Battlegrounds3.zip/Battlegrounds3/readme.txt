[PSP-Hacks Homebrew Idol 2]
Battlegrounds 3 - v0.4
by Xfacter

[About]
BG3 is a hovertank deathmatch game. Using a variety of weapons, defeat your opponents to bring glory to your homeland.

[Controls]
Movement - TRIANGLE, CIRCLE, CROSS, SQUARE
Look - Analog Nub
Change Weapon - D-Pad Left/Right
Fire - Right Trigger

(Note: Change look inversion and analog deadzone in the config.ini file)

[Gameplay]
There are a range of weapons in BG3 with varying levels of effectiveness. In order to defeat an enemy you must deplete his shields and armor.
The machine gun is a good all-around weapon. The laser is effective against shields. The tank shells are effective against armor.
The missiles are better all-around weapons.

[Credits]
Design, Coding, Graphics - Alex Wickes "Xfacter"
Tank Model - Harry
Sound FX - http://www.sounddogs.com/

[Special Thanks]
#psp-programing on irc.freenode.net - Couldn't have done it without you guys.

[Contact]
If you have questions email me at xfacter@gmail.com